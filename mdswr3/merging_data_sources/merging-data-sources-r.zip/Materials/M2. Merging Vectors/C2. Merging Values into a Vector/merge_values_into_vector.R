c(2:9)
v <- c(2:9)
c(1, v)
v <- c(1, v)
v
c(v, 10)
v <- c(v, 10)
is.vector(1)
is.vector(v)
v1 <- c(1:5)
v2 <- c(6:10)
c(v1, v2)
c(v2, v1)
poem <- c('Mary', 'little', 'lamb')
?append
append(poem, c('had', 'a'), after = 1)
append
v
v <- c(v, 11)
v
v <- c(v, 12)
v <- c(v, 13)
v <- c(v, 14)
v <- c(v, 15)
v
v <- 1:10
v <- c(v, 11:15)
v
