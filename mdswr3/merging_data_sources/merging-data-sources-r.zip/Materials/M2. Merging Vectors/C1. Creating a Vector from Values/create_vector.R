1:5
1:50
v <- 1:5
v

x <- 1:3
y <- 4:6
plot(x, y)

is.vector(v)
is.vector(x)
typeof(x)
is.vector(1)
is.vector(FALSE)
is.vector('hello')
typeof('hello')

c(1, 100, 200)
countries <- c('USA', 'UK')
is.vector(countries)
typeof(countries)

length(c('small', 'big'))
nchar('small')

mix <- c(1, TRUE, 'way')
mix

funny <- c(1, 2, c(4, 5, c(6, 'seven')))