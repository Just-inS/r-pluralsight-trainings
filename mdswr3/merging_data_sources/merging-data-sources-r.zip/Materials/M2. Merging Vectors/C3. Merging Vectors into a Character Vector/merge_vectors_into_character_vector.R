2 + 2
'hello' + 'world'
is.vector('hello')
length('hello')
nchar('hello')
c('h', 'e', 'l', 'l', 'o')
paste('hello', 'world')
?paste
paste('hello', 'world', sep = '')
paste('hello', 'world', sep = ', ')
paste('one', 'two', 'three')
paste(1, 'two', TRUE)
paste(c('name', 'age'), c('John', 5))
paste(c('name', 'age'), c('John', 5))
   
paste(c('name', 'age'), 
+       c('John', 5),
+       c('Doe', 'years'))

paste(c('name', 'age'), 
+       c('John', 5),
+       c('Doe', 'years'), collapse = '-')

paste(c('name', 'age', 'Name', 'Age'), 
+       c('John', 5))

paste(c('name', 'age', 'Name', 'Age'), 
+       c('John', 5,      'John', 5))

paste(c('name', 'age', 'Name', 'Age', 'Other'), 
+       c('John', 5,      'John', 5))

c(1, 2) + 3

c(1, 2) + c(3, 3)
