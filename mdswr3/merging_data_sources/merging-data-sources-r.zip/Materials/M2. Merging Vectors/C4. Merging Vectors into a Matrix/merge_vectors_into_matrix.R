first_matrix <- matrix(1, nrow = 2, ncol = 3)
first_matrix
is.matrix(first_matrix)
is.vector(first_matrix)
typeof(first_matrix)
length(first_matrix)
first_matrix
larger_matrix <- matrix(1:9, nrow = 3, ncol = 3)
larger_matrix
second_col <- larger_matrix[,2]
second_col
is.vector(second_col)
third_row <- larger_matrix[3,]
is.vector(third_row)
cbind('hello', 'world')
rbind('hello', 'world')
cbind(c(1, 2, 3), c(4, 5, 6))
rbind(c(1, 2, 3), c(4, 5, 6))
cbind(c(1, 2, 3), 5)
rbind(c('a', 'b', 'c', 'd', 'e'), c(1, 2), TRUE)
 