library(dplyr)

ls('package:dplyr')
